#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2025 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors
"""


import numpy as np
from kaiwu_agent.utils.common_func import attached, create_cls
from agent_dqn.conf.conf import Config

# The create_cls function is used to dynamically create a class. The first parameter of the function is the type name,
# and the remaining parameters are the attributes of the class, which should have a default value of None.
# create_cls函数用于动态创建一个类，函数第一个参数为类型名称，剩余参数为类的属性，属性默认值应设为None
ObsData = create_cls(
    "ObsData",
    feature=None,
    legal_act=None,
)


ActData = create_cls(
    "ActData",
    move_dir=None,
    use_talent=None,
)


SampleData = create_cls(
    "SampleData",
    obs=None,
    _obs=None,
    obs_legal=None,
    _obs_legal=None,
    act=None,
    rew=None,
    ret=None,
    done=None,
)

RelativeDistance = {
    "RELATIVE_DISTANCE_NONE": 0,
    "VerySmall": 1,
    "Small": 2,
    "Medium": 3,
    "Large": 4,
    "VeryLarge": 5,
}


RelativeDirection = {
    "East": 1,
    "NorthEast": 2,
    "North": 3,
    "NorthWest": 4,
    "West": 5,
    "SouthWest": 6,
    "South": 7,
    "SouthEast": 8,
}

DirectionAngles = {
    1: 0,
    2: 45,
    3: 90,
    4: 135,
    5: 180,
    6: 225,
    7: 270,
    8: 315,
}


def reward_process(end_dist, history_dist):
    # step reward
    # 步数奖励
    step_reward = -0.001

    # end reward
    # 终点奖励
    end_reward = -0.02 * end_dist

    # distance reward
    # 距离奖励
    dist_reward = min(0.001, 0.05 * history_dist)

    return [step_reward + dist_reward + end_reward]


# def reward_process(end_dist, history_dist, found_event, collision, flash_used, chest_count, progress):
#     """
#     计算当前步的奖励值。
#     参数:
#         end_dist (float): 当前帧智能体与终点的归一化距离 (0~1)。
#         history_dist (float): 当前帧智能体与若干步之前位置的归一化距离，用于衡量移动幅度。
#         found_event (int): 是否在本步首次发现终点（是为1，否则0）。
#         collision (int): 上一步动作是否发生碰撞/无效移动（是为1，否则0）。
#         flash_used (int): 上一步动作是否使用了闪现技能（是为1，否则0）。
#         chest_count (int): 本步拾取的宝箱数量。
#         progress (float): 当前步相对于上一步终点距离的缩短量（正值表示更接近终点，负值表示远离）。
#     返回:
#         [reward] (list of float): 长度1的列表，包含当前步综合得到的奖励值。
#     """
#     # 1. 每步时间惩罚：鼓励用更少步数完成
#     step_reward = -0.005  # 每走一步扣0.005分

#     # 2. 终点距离奖励：距离终点越远惩罚越大，越近惩罚减小
#     end_reward = -0.02 * end_dist  # 终点距离归一化值乘以-0.02

#     # 3. 移动距离奖励：根据近期移动幅度奖励，避免原地不动
#     dist_reward = min(0.002, 0.1 * history_dist)  # 最近若干步累计位移，封顶奖励0.002

#     # 4. 碰撞惩罚：如果上一步撞墙/无效，则给予较大惩罚
#     obstacle_penalty = -0.1 if collision == 1 else 0.0

#     # 5. 宝箱奖励：每获得一个宝箱奖励+5.0
#     chest_reward = 5.0 * chest_count

#     # 6. 终点发现奖励：首次看到终点时奖励+3.0
#     vision_reward = 3.0 if found_event == 1 else 0.0

#     # 7. 距离进展奖励：根据与终点距离的变化趋势奖励/惩罚
#     progress_reward = 0.05 * progress  # 若本步靠近终点则为正，远离则为负

#     # 汇总所有奖励分量
#     total_reward = step_reward + end_reward + dist_reward + obstacle_penalty \
#                    + chest_reward + vision_reward + progress_reward
#     return [total_reward]



@attached
def sample_process(list_game_data):
    return [SampleData(**i.__dict__) for i in list_game_data]


@attached
def SampleData2NumpyData(g_data):
    return np.hstack(
        (
            np.array(g_data.obs, dtype=np.float32),
            np.array(g_data._obs, dtype=np.float32),
            np.array(g_data.obs_legal, dtype=np.float32),
            np.array(g_data._obs_legal, dtype=np.float32),
            np.array(g_data.act, dtype=np.float32),
            np.array(g_data.rew, dtype=np.float32),
            np.array(g_data.ret, dtype=np.float32),
            np.array(g_data.done, dtype=np.float32),
        )
    )


@attached
def NumpyData2SampleData(s_data):
    obs_data_size = Config.DIM_OF_OBSERVATION
    legal_data_size = Config.DIM_OF_ACTION
    return SampleData(
        obs=s_data[:obs_data_size],
        _obs=s_data[obs_data_size : 2 * obs_data_size],
        obs_legal=s_data[2 * obs_data_size : 2 * obs_data_size + legal_data_size],
        _obs_legal=s_data[2 * obs_data_size + legal_data_size : 2 * obs_data_size + 2 * legal_data_size],
        act=s_data[-4],
        rew=s_data[-3],
        ret=s_data[-2],
        done=s_data[-1],
    )
